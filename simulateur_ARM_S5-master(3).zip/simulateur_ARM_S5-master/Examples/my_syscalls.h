#ifndef __MY_PUTCHAR_H__
#define __MY_PUTCHAR_H__

void my_exit();
void my_putchar(char c);

#endif
